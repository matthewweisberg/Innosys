﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ColorTrackBench
{
    public static class Utils
    {
        #region Calculate Statistics

        public static double CalculateAverage(List<double> readings)
        {
            double avg = 0;
            for (int i = 0; i < readings.Count; i++)
            {
                avg += readings[i];
            }
            avg /= readings.Count;

            return avg;
        }

        public static double CalculateStandardDeviation(List<double> readings)
        {
            double avg = 0;
            for (int i = 0; i < readings.Count; i++)
            {
                avg += readings[i];
            }
            avg /= readings.Count;

            double sumDeviationsSquared = 0;
            for (int i = 0; i < readings.Count; i++)
            {
                sumDeviationsSquared += Math.Pow(readings[i] - avg, 2);
            }
            sumDeviationsSquared /= (readings.Count - 1);

            return Math.Pow(sumDeviationsSquared, 0.5);
        }

        public static double CalculateMode(Dictionary<int, int> histogramBins)
        {
            double modeReadings = double.MinValue;
            double modeValue = 0;

            foreach (int reading in histogramBins.Keys)
            {
                if (histogramBins[reading] > modeReadings)
                {
                    modeReadings = histogramBins[reading];
                    modeValue = reading;
                }
            }

            return modeValue;
        }

        public static double CalculateMinimum(List<double> readings)
        {
            double min = double.MaxValue;
            for (int i = 0; i < readings.Count; i++)
            {
                if (readings[i] < min)
                {
                    min = readings[i];
                }
            }

            return min;
        }

        public static double CalculateMaximum(List<double> readings)
        {
            double max = double.MinValue;
            for (int i = 0; i < readings.Count; i++)
            {
                if (readings[i] > max)
                {
                    max = readings[i];
                }
            }

            return max;
        }

        public static Dictionary<int, int> CalculateHistogramBins(List<double> readings)
        {
            Dictionary<int, int> bins = new Dictionary<int, int>();

            for (int i = 0; i < readings.Count; i++)
            {
                int reading = (int)Math.Round(readings[i], 0, MidpointRounding.AwayFromZero);
                if (bins.ContainsKey(reading))
                {
                    bins[reading]++;
                }
                else
                {
                    bins.Add(reading, 1);
                }
            }

            return bins;
        }

        #endregion
    }
}
