﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Collections.ObjectModel;
using System.Windows.Controls.DataVisualization.Charting;
using Microsoft.Win32;
using System.IO;
using ColorTrackBench.Common;

namespace ColorTrackBench
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private CTScan LoadedColorTrackScan;
        private CTScan LoadedColorTrackScanCompareTo;
        private ObservableCollection<CTAttribute> loadedColorTrackAttributes = new ObservableCollection<CTAttribute>();
        private ObservableCollection<HistogramBins> Histogram = new ObservableCollection<HistogramBins>();
        private ObservableCollection<HistogramBins> HistogramCompareTo = new ObservableCollection<HistogramBins>();

        public MainWindow()
        {
            InitializeComponent();
            initializeScaleChoice();

            App.ILaserManager.ScanStarted += new Action(ColorTrackManager_ScanStarted);
            App.ILaserManager.ScanCompleted += new Action<CTScan>(ColorTrackManager_ScanCompleted);
            App.ILaserManager.LaserConnected += new Action(ColorTrackManager_USB6008Connected);
            App.ILaserManager.LaserDisconnected += new Action(ColorTrackManager_USB6008Disconnected);

            dgAttributes.ItemsSource = loadedColorTrackAttributes;

            hideControls();

            tbStatus.Visibility = System.Windows.Visibility.Visible;
            pbScanning.Visibility = System.Windows.Visibility.Collapsed;
        }

        private void initializeScaleChoice()
        {
            /*Console.WriteLine("InitializeScaleChoice : " + App.ColorTrackConfig.Scale);
            if (App.ColorTrackConfig.Scale == "ColorTrack")
            {
                cbxScale.SelectedIndex = 0;
            }
            else
            {
                cbxScale.SelectedIndex = 1;
            }*/
        }

        private void ColorTrackManager_USB6008Disconnected()
        {
            Console.WriteLine("ColorTrackManager_USB6008Disconnected");
            this.Dispatcher.Invoke(DispatcherPriority.Normal, (Action)delegate()
            {
                tbStatus.Text = "Laser is not connected.";
            });
        }

        private void ColorTrackManager_USB6008Connected()
        {
            Console.WriteLine("ColorTrackManager_USB6008Connected");
            this.Dispatcher.Invoke(DispatcherPriority.Normal, (Action)delegate()
            {
                tbStatus.Text = "Ready";
            });
        }

        private void ColorTrackManager_ScanStarted()
        {
            Console.WriteLine("ColorTrackManager_ScanStarted");

            this.Dispatcher.Invoke(DispatcherPriority.Normal, (Action)delegate()
            {
                hideControls();
            });
        }

        private void hideControls()
        {
            pbScanning.Visibility = System.Windows.Visibility.Visible;
            tbStatus.Visibility = System.Windows.Visibility.Collapsed;

            tbAverageTitle.Visibility = System.Windows.Visibility.Collapsed;
            tbStdDevTitle.Visibility = System.Windows.Visibility.Collapsed;
            tbMaximumTitle.Visibility = System.Windows.Visibility.Collapsed;
            tbMinimumTitle.Visibility = System.Windows.Visibility.Collapsed;
            tbModeTitle.Visibility = System.Windows.Visibility.Collapsed;

            tbAverage.Visibility = System.Windows.Visibility.Collapsed;
            tbStdDev.Visibility = System.Windows.Visibility.Collapsed;
            tbMaximum.Visibility = System.Windows.Visibility.Collapsed;
            tbMinimum.Visibility = System.Windows.Visibility.Collapsed;
            tbMode.Visibility = System.Windows.Visibility.Collapsed;

            tbScanTimeTitle.Visibility = System.Windows.Visibility.Collapsed;
            tbScanTime.Visibility = System.Windows.Visibility.Collapsed;

            tbScaleTitle.Visibility = System.Windows.Visibility.Collapsed;
            cbxScale.Visibility = System.Windows.Visibility.Collapsed;

            crtScan.Visibility = System.Windows.Visibility.Collapsed;

            tbCommentsTitle.Visibility = System.Windows.Visibility.Collapsed;
            txtComments.Visibility = System.Windows.Visibility.Collapsed;

            btnCompareTo.Visibility = System.Windows.Visibility.Collapsed;
            btnExportToCsv.Visibility = System.Windows.Visibility.Collapsed;

            tbAttributesTitle.Visibility = System.Windows.Visibility.Collapsed;
            dgAttributes.Visibility = System.Windows.Visibility.Collapsed;

            tbScanSettingsTitle.Visibility = System.Windows.Visibility.Collapsed;
            bScanSettingsTitle.Visibility = System.Windows.Visibility.Collapsed;

            tbReadingsTitle.Visibility = System.Windows.Visibility.Collapsed;
            tbNumReadingsTitle.Visibility = System.Windows.Visibility.Collapsed;
        }

        private void ColorTrackManager_ScanCompleted(CTScan colorTrackScan)
        {
            Console.WriteLine("ColorTrackManager_ScanCompleted");
            
            Console.WriteLine(colorTrackScan.Name);

            this.Dispatcher.Invoke(DispatcherPriority.Normal, (Action)delegate()
            {
                showControls();

                loadColorTrackScan(colorTrackScan);
            });
        }

        private void showControls()
        {
            tbStatus.Visibility = System.Windows.Visibility.Visible;
            pbScanning.Visibility = System.Windows.Visibility.Collapsed;

            tbAverageTitle.Visibility = System.Windows.Visibility.Visible;
            tbStdDevTitle.Visibility = System.Windows.Visibility.Visible;
            tbMaximumTitle.Visibility = System.Windows.Visibility.Visible;
            tbMinimumTitle.Visibility = System.Windows.Visibility.Visible;
            tbModeTitle.Visibility = System.Windows.Visibility.Visible;

            tbAverage.Visibility = System.Windows.Visibility.Visible;
            tbStdDev.Visibility = System.Windows.Visibility.Visible;
            tbMaximum.Visibility = System.Windows.Visibility.Visible;
            tbMinimum.Visibility = System.Windows.Visibility.Visible;
            tbMode.Visibility = System.Windows.Visibility.Visible;

            tbScanTimeTitle.Visibility = System.Windows.Visibility.Visible;
            tbScanTime.Visibility = System.Windows.Visibility.Visible;

            tbScaleTitle.Visibility = System.Windows.Visibility.Visible;
            cbxScale.Visibility = System.Windows.Visibility.Visible;

            crtScan.Visibility = System.Windows.Visibility.Visible;

            tbCommentsTitle.Visibility = System.Windows.Visibility.Visible;
            txtComments.Visibility = System.Windows.Visibility.Visible;

            btnCompareTo.Visibility = System.Windows.Visibility.Visible;
            btnExportToCsv.Visibility = System.Windows.Visibility.Visible;

            tbAttributesTitle.Visibility = System.Windows.Visibility.Visible;
            dgAttributes.Visibility = System.Windows.Visibility.Visible;

            tbScanSettingsTitle.Visibility = System.Windows.Visibility.Visible;
            bScanSettingsTitle.Visibility = System.Windows.Visibility.Visible;

            tbReadingsTitle.Visibility = System.Windows.Visibility.Visible;
            tbNumReadingsTitle.Visibility = System.Windows.Visibility.Visible;
        }

        private void loadColorTrackScan(CTScan colorTrackScan)
        {
            tbScanTime.Text = String.Format("{0:f}", colorTrackScan.DateTime);
            //tbScanTime.Text = colorTrackScan.DateTime.ToString();

            LoadedColorTrackScan = colorTrackScan;

            txtComments.DataContext = LoadedColorTrackScan.Comments;
            txtComments.Text = LoadedColorTrackScan.Comments;

            loadedColorTrackAttributes.Clear();
            foreach (string attributeKey in LoadedColorTrackScan.Attributes.Keys)
            {
                loadedColorTrackAttributes.Add(new CTAttribute()
                {
                    Name = attributeKey,
                    Value = LoadedColorTrackScan.Attributes[attributeKey]
                });
            }

            dgAttributes.ItemsSource = loadedColorTrackAttributes;

            cbxScale.Items.Clear();
            foreach (string scale in colorTrackScan.ScanResults.Keys)
            {
                cbxScale.Items.Add(scale);
            }

            if (cbxScale.Items.Count > 0)
            {
                if (cbxScale.Items.Contains(App.ColorTrackConfig.Scale))
                {
                    cbxScale.SelectedValue = App.ColorTrackConfig.Scale;
                }
                else
                {
                    cbxScale.SelectedIndex = 0;
                }

                updateScanResults(colorTrackScan.ScanResults[(string)cbxScale.SelectedItem]);
            }

            txtComments.Text = colorTrackScan.Comments;

            showControls();
        }

        private void loadColorTrackScanCompareTo(CTScan colorTrackScan)
        {
            LoadedColorTrackScanCompareTo = colorTrackScan;

            updateScanResultsCompareTo(colorTrackScan.ScanResults[(string)cbxScale.SelectedItem]);
        }

        private void updateScanResults(CTScanResult scanResult)
        {
            tbAverage.Text = Math.Round(scanResult.Average, App.ColorTrackConfig.NumberOfDecimalsAverage).ToString();
            tbStdDev.Text = Math.Round(scanResult.StandardDeviation, App.ColorTrackConfig.NumberOfDecimalsStandardDeviation).ToString();
            tbMode.Text = Math.Round(scanResult.Mode, App.ColorTrackConfig.NumberOfDecimalsAverage).ToString();
            tbMinimum.Text = Math.Round(scanResult.Minimum, App.ColorTrackConfig.NumberOfDecimalsAverage).ToString();
            tbMaximum.Text = Math.Round(scanResult.Maximum, App.ColorTrackConfig.NumberOfDecimalsAverage).ToString();

            txtComments.Text = "";

            /*crtColorTrackScan.Series.Clear();
            crtColorTrackScan.Series.Add(scanResult.ScaleName);
            crtColorTrackScan.Series[scanResult.ScaleName].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Column;
            */
            int maximumYCount = 0;

            Histogram.Clear();
            HistogramCompareTo.Clear();

            int maxKey = 0;
            foreach (var histogramBinKey in scanResult.HistogramBins.Keys)
            {
                if (histogramBinKey > maxKey)
                    maxKey = histogramBinKey;
            }

            for (int i = 0; i <= maxKey; i++)
            {
                if (scanResult.HistogramBins.ContainsKey(i))
                {
                    //crtColorTrackScan.Series[scanResult.ScaleName].Points.AddXY(i, scanResult.HistogramBins[i]);
                    Histogram.Add(new HistogramBins()
                    {
                        Bin = i,
                        Frequency = scanResult.HistogramBins[i]
                    });

                    if (scanResult.HistogramBins[i] > maximumYCount)
                    {
                        maximumYCount = scanResult.HistogramBins[i];
                    }
                }
                else
                {
                    Histogram.Add(new HistogramBins()
                    {
                        Bin = i,
                        Frequency = 0
                    });
                    //crtColorTrackScan.Series[scanResult.ScaleName].Points.AddXY(i, 0);
                }
            }

            (crtScan.Series[0] as LineSeries).ItemsSource = Histogram;

            //crtColorTrackScan.ChartAreas[0].AxisY.Maximum = maximumYCount * 1.1;
        }

        private void updateScanResultsCompareTo(CTScanResult scanResult)
        {
            tbAverage.Text += " (" + Math.Round(scanResult.Average, App.ColorTrackConfig.NumberOfDecimalsAverage).ToString() + ")";
            tbStdDev.Text += " (" + Math.Round(scanResult.StandardDeviation, App.ColorTrackConfig.NumberOfDecimalsStandardDeviation).ToString() + ")";
            tbMode.Text += " (" + Math.Round(scanResult.Mode, App.ColorTrackConfig.NumberOfDecimalsAverage).ToString() + ")";
            tbMinimum.Text += " (" + Math.Round(scanResult.Minimum, App.ColorTrackConfig.NumberOfDecimalsAverage).ToString() + ")";
            tbMaximum.Text += " (" + Math.Round(scanResult.Maximum, App.ColorTrackConfig.NumberOfDecimalsAverage).ToString() + ")";

            int maximumYCount = 0;

            HistogramCompareTo.Clear();

            var maxKey = 0;
            foreach (var histogramBinKey in scanResult.HistogramBins.Keys)
            {
                if (histogramBinKey > maxKey)
                    maxKey = histogramBinKey;
            }

            for (int i = 0; i <= maxKey; i++)
            {
                if (scanResult.HistogramBins.ContainsKey(i))
                {
                    HistogramCompareTo.Add(new HistogramBins()
                    {
                        Bin = i,
                        Frequency = scanResult.HistogramBins[i]
                    });

                    if (scanResult.HistogramBins[i] > maximumYCount)
                    {
                        maximumYCount = scanResult.HistogramBins[i];
                    }
                }
                else
                {
                    HistogramCompareTo.Add(new HistogramBins()
                    {
                        Bin = i,
                        Frequency = 0
                    });
                }
            }

            (crtScan.Series[1] as LineSeries).ItemsSource = HistogramCompareTo;
        }

        private void syncAttributes()
        {
            if (LoadedColorTrackScan.Attributes != null)
            {
                LoadedColorTrackScan.Attributes.Clear();
            }

            LoadedColorTrackScan.Attributes = new Dictionary<string, string>();

            foreach (CTAttribute colorTrackAttribute in loadedColorTrackAttributes)
            {
                LoadedColorTrackScan.Attributes.Add(colorTrackAttribute.Name, colorTrackAttribute.Value);
            }
        }

        private void cbxScale_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cbxScale.Items.Count > 0)
            {
                Console.WriteLine("Scale Changed");
                updateResultsIfScanLoaded();
                updateResultsIfScanLoadedCompareTo();

                App.ColorTrackConfig.Scale = (string)cbxScale.SelectedItem;
                App.SaveColorTrackConfig();
            }

            if (cbxScale.SelectedValue != null)
            {
                App.ColorTrackConfig.Scale = cbxScale.SelectedValue.ToString();
                App.SaveColorTrackConfig();
            }
        }

        private void updateResultsIfScanLoaded()
        {
            if (LoadedColorTrackScan != null &&
                LoadedColorTrackScan.ScanResults != null)
            {
                if (LoadedColorTrackScan.ScanResults.ContainsKey((string)cbxScale.SelectedItem))
                {
                    updateScanResults(LoadedColorTrackScan.ScanResults[(string)cbxScale.SelectedItem]);
                }
            }
        }

        private void updateResultsIfScanLoadedCompareTo()
        {
            if (LoadedColorTrackScanCompareTo != null &&
                LoadedColorTrackScanCompareTo.ScanResults != null)
            {
                if (LoadedColorTrackScanCompareTo.ScanResults.ContainsKey((string)cbxScale.SelectedItem))
                {
                    updateScanResultsCompareTo(LoadedColorTrackScanCompareTo.ScanResults[(string)cbxScale.SelectedItem]);
                }
            }
        }

        private void txtComments_TextChanged(object sender, TextChangedEventArgs e)
        {
            Console.WriteLine("TextChanged");
            if (LoadedColorTrackScan != null)
            {
                //LoadedColorTrackScan.Comments = txtComments.Text;
            }
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            App.ILaserManager.Stop();
            App.Current.Shutdown();
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            App.Current.Shutdown();
            this.Close();
        }

        private void imgAttributes_MouseDown(object sender, MouseButtonEventArgs e)
        {
            DefaultAttributesWindow dfw = new DefaultAttributesWindow();
            dfw.ShowDialog();
        }

        private void imgPrecision_MouseDown(object sender, MouseButtonEventArgs e)
        {
            AdjustPrecisionWindow apw = new AdjustPrecisionWindow();
            apw.ShowDialog();

            updateResultsIfScanLoaded();
            updateResultsIfScanLoadedCompareTo();
        }

        private void imgScales_MouseDown(object sender, MouseButtonEventArgs e)
        {
            ScalesWindow sw = new ScalesWindow();
            sw.ShowDialog();
        }

        private void imgLicense_MouseDown(object sender, MouseButtonEventArgs e)
        {
            LicensingInformationWindow liw = new LicensingInformationWindow();
            liw.ShowDialog();
        }

        private void imgExit_MouseDown(object sender, MouseButtonEventArgs e)
        {
            App.Current.Shutdown();
        }

        private void imgStopManualScan_MouseDown(object sender, MouseButtonEventArgs e)
        {
            App.ILaserManager.StopManualScan();
        }

        private void imgStartManualScan_MouseDown(object sender, MouseButtonEventArgs e)
        {
            App.ILaserManager.StartManualScan();
        }

        private void rbAutoStartScanOn_Checked(object sender, RoutedEventArgs e)
        {
            App.ILaserManager.SetManualStartStop(false);
            imgStartManualScan.IsEnabled = false;
            imgStopManualScan.IsEnabled = false;

            imgStartManualScan.Opacity = 0.5;
            imgStopManualScan.Opacity = 0.2;

            tbStartManualScan.Opacity = 0.4;
            tbStopManualScan.Opacity = 0.4;
        }

        private void rbAutoStartScanOff_Checked(object sender, RoutedEventArgs e)
        {
            App.ILaserManager.SetManualStartStop(true);
            imgStartManualScan.IsEnabled = true;
            imgStopManualScan.IsEnabled = true;

            imgStartManualScan.Opacity = 1.0;
            imgStopManualScan.Opacity = 1.0;

            tbStartManualScan.Opacity = 1.0;
            tbStopManualScan.Opacity = 1.0;
        }

        private void imgOpen_MouseDown(object sender, MouseButtonEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "ColorTrack Scans (*.ctf)|*.ctf";
            openFileDialog.InitialDirectory = App.COLORTRACK_DIRECTORY;
            openFileDialog.Multiselect = false;

            bool? res = openFileDialog.ShowDialog();

            if (res.HasValue &&
                res.Value)
            {
                CTScan colorTrackScan;
                bool loadRes = App.ColorTrackManager.LoadColorTrackScan(openFileDialog.FileName, out colorTrackScan);

                if (loadRes)
                {
                    loadColorTrackScan(colorTrackScan);
                }
            }
        }

        private void imgSave_MouseDown(object sender, MouseButtonEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "ColorTrack Scans (*.ctf)|*.ctf";
            saveFileDialog.InitialDirectory = App.COLORTRACK_DIRECTORY;

            bool? res = saveFileDialog.ShowDialog();

            if (res.HasValue &&
                res.Value)
            {
                LoadedColorTrackScan.Comments = txtComments.Text;
                
                LoadedColorTrackScan.Attributes.Clear();
                foreach (CTAttribute colorTrackAttribute in loadedColorTrackAttributes)
                {
                    LoadedColorTrackScan.Attributes.Add(colorTrackAttribute.Name, colorTrackAttribute.Value);
                }

                bool saveRes = App.ColorTrackManager.SaveColorTrackScan(saveFileDialog.FileName, LoadedColorTrackScan);

                if (saveRes)
                {
                    MessageBox.Show("File saved successfully");
                }
                else
                {
                    MessageBox.Show("File was not saved successfully.  Please try again");
                }
            }
        }

        private void btnExportToCsv_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Comma Separated Values (*.csv)|*.csv";
            saveFileDialog.InitialDirectory = App.COLORTRACK_DIRECTORY;

            bool? res = saveFileDialog.ShowDialog();

            if (res.HasValue &&
                res.Value)
            {
                bool saveRes = false;
                StreamWriter sw = null;

                try
                {
                    sw = new StreamWriter(saveFileDialog.FileName);

                    sw.WriteLine("Scan: {0}", LoadedColorTrackScan.Name);
                    sw.WriteLine("Time of Scan: {0}", LoadedColorTrackScan.DateTime);
                    sw.WriteLine();
                    
                    sw.WriteLine("Scale Name, Average, Standard Deviation, Minimum, Maximum, Mode");
                    foreach (var scanResult in LoadedColorTrackScan.ScanResults)
                    {
                        sw.WriteLine("{0}, {1}, {2}, {3}, {4}, {5}", scanResult.Value.ScaleName, scanResult.Value.Average, scanResult.Value.StandardDeviation, scanResult.Value.Minimum, scanResult.Value.Maximum, scanResult.Value.Mode);
                    }

                    sw.WriteLine();

                    sw.WriteLine("Histogram Data");
                    sw.WriteLine();
                    
                    foreach (var scanResult in LoadedColorTrackScan.ScanResults)
                    {
                        sw.WriteLine("Reading for {0} scale, Number of Readings", scanResult.Value.ScaleName);
                        foreach (var bin in scanResult.Value.HistogramBins) 
                        {
                            sw.WriteLine("{0}, {1}", bin.Key, bin.Value);
                        }
                        sw.WriteLine();
                    }

                    sw.Flush();

                    saveRes = true;
                }
                catch
                {
                    saveRes = false;
                }
                finally
                {
                    if (sw != null)
                    {
                        sw.Close();
                    }
                }

                if (saveRes)
                {
                    MessageBox.Show("File saved successfully");
                }
                else
                {
                    MessageBox.Show("File was not saved successfully.  Please try again");
                }
            }
        }

        private void btnCompareTo_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "ColorTrack Scans (*.ctf)|*.ctf";
            openFileDialog.InitialDirectory = App.COLORTRACK_DIRECTORY;
            openFileDialog.Multiselect = false;

            bool? res = openFileDialog.ShowDialog();

            if (res.HasValue &&
                res.Value)
            {
                CTScan colorTrackScan;
                bool loadRes = App.ColorTrackManager.LoadColorTrackScan(openFileDialog.FileName, out colorTrackScan);

                if (loadRes)
                {
                    loadColorTrackScanCompareTo(colorTrackScan);
                }
            }
        }
    }

    public class HistogramBins
    {
        public int Bin { get; set; }
        public int Frequency { get; set; }
    }
}
