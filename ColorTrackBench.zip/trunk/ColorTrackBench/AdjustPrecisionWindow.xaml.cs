﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Interop;
using System.Runtime.InteropServices;

namespace ColorTrackBench
{
    /// <summary>
    /// Interaction logic for AdjustPrecisionWindow.xaml
    /// </summary>
    public partial class AdjustPrecisionWindow : Window
    {
        #region Remove Close Button

        private const int GWL_STYLE = -16;
        private const int WS_SYSMENU = 0x80000;

        [DllImport("user32.dll", SetLastError = true)]
        private static extern int GetWindowLong(IntPtr hWnd, int nIndex);

        [DllImport("user32.dll")]
        private static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var hwnd = new WindowInteropHelper(this).Handle;
            SetWindowLong(hwnd, GWL_STYLE, GetWindowLong(hwnd, GWL_STYLE) & ~WS_SYSMENU);
        }

        #endregion Remove Close Button

        public AdjustPrecisionWindow()
        {
            InitializeComponent();

            txtAverageDecimals.Text = App.ColorTrackConfig.NumberOfDecimalsAverage.ToString();
            txtStandardDeviationDecimals.Text = App.ColorTrackConfig.NumberOfDecimalsStandardDeviation.ToString();
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            int numberOfAverageDecimals, numberOfStandardDeviationDecimals;

            if (int.TryParse(txtAverageDecimals.Text, out numberOfAverageDecimals) &&
                int.TryParse(txtStandardDeviationDecimals.Text, out numberOfStandardDeviationDecimals))
            {
                App.ColorTrackConfig.NumberOfDecimalsAverage = numberOfAverageDecimals;
                App.ColorTrackConfig.NumberOfDecimalsStandardDeviation = numberOfStandardDeviationDecimals;

                App.SaveColorTrackConfig();
                this.Close();
            }
            else
            {
                MessageBox.Show("Invalid numbers entered.  Please try again.",
                                "Invalid numbers entered",
                                MessageBoxButton.OK,
                                MessageBoxImage.Error);
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
