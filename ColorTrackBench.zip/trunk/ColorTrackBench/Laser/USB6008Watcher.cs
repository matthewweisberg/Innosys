﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Timers;
using NationalInstruments.DAQmx;

namespace ColorTrackBench.Laser
{
    /// <summary>
    /// Watches for the connection and disconnection of the USB-6008 module
    /// </summary>
    public class USB6008Watcher
    {
        private Timer _pollingTimer;

        public event Action USB6008Connected;

        public event Action USB6008Disconnected;

        public bool IsUSB6008Connected
        {
            get;
            private set;
        }

        public void Start()
        {
            _pollingTimer = new Timer(2000);
            _pollingTimer.Elapsed += new ElapsedEventHandler(PollingTimer_Elapsed);
            _pollingTimer.Start();
        }

        public void Stop()
        {
            _pollingTimer.Stop();
            _pollingTimer.Dispose();
            _pollingTimer = null;
        }

        private void PollingTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            try
            {
                string[] channels = null;

                channels = DaqSystem.Local.GetPhysicalChannels(PhysicalChannelTypes.AI, PhysicalChannelAccess.External);

                if (channels.Length == 0)
                {
                    if (IsUSB6008Connected)
                    {
                        OnUSB6008Disconnected();
                    }
                }
                else
                {
                    if (!IsUSB6008Connected)
                    {
                        OnUSB6008Connected();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void OnUSB6008Connected()
        {
            IsUSB6008Connected = true;

            if (USB6008Connected != null)
                USB6008Connected();
        }

        private void OnUSB6008Disconnected()
        {
            IsUSB6008Connected = false;

            if (USB6008Disconnected != null)
                USB6008Disconnected();
        }
    }
}