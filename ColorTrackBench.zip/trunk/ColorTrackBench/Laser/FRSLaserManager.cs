﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml;
using System.Runtime.Serialization;
using NationalInstruments.DAQmx;
using ColorTrackBench.Common;

namespace ColorTrackBench.Laser
{
    public class FRSLaserManager : ILaserManager
    {
        #region Fields

        private const double START_VOLTAGE_TRIGGER = 9.0;
        private const double STOP_VOLTAGE_TRIGGER = 9.0;
        private const double VOLTAGE_READING_LOWER_BOUND = 2.0;

        private USB6008Watcher _usb6008Watcher = new USB6008Watcher();
        private AnalogMultiChannelReader _usb6008Reader;
        private Task _usb6008Task;

        private string _physicalChannelLaser = string.Empty;
        private string _physicalChannelTrigger = string.Empty;

        private bool _readSamples;
        private bool _readingSample;
        private bool _isLaserConnected;
        private bool _isManualStartStop;
        private bool _isManualScanStarted;
        private List<double> _laserReadings = new List<double>();
        
        #endregion

        #region Constructor

        public FRSLaserManager()
        {
            _readSamples = true;

            _usb6008Watcher.USB6008Connected += new Action(USB6008Watcher_USB6008Connected);
            _usb6008Watcher.USB6008Disconnected += new Action(USB6008Watcher_USB6008Disconnected);
            _usb6008Watcher.Start();
        }

        #endregion

        #region ILaserManager Members

        public event Action LaserConnected;
        public event Action LaserDisconnected;

        public event Action ScanStarted;
        public event Action<CTScan> ScanCompleted;

        public void Stop()
        {
            _readSamples = false;
        }

        public void SetManualStartStop(bool manualStartStop)
        {
            _isManualStartStop = manualStartStop;
        }

        public void StartManualScan()
        {
            _isManualScanStarted = true;
        }

        public void StopManualScan()
        {
            _isManualScanStarted = false;
        }

        #endregion

        #region Functions

        private void USB6008Watcher_USB6008Connected()
        {
            _isLaserConnected = true;

            if (LaserConnected != null)
            {
                try
                {
                    LaserConnected();
                }
                catch { }
            }

            SetPhysicalChannels();

            CreateTask();
            CreateUSB6008Reader();

            StartTask();

            StartReadingUSB6008Data();
        }

        private void USB6008Watcher_USB6008Disconnected()
        {
            _isLaserConnected = false;

            if (LaserDisconnected != null)
            {
                try
                {
                    LaserDisconnected();
                }
                catch { }
            }
        }

        private bool SetPhysicalChannels()
        {
            try
            {
                string[] Channels = DaqSystem.Local.GetPhysicalChannels(PhysicalChannelTypes.AI, PhysicalChannelAccess.External);

                _physicalChannelLaser = string.Empty;
                _physicalChannelTrigger = string.Empty;

                if (Channels.Length != 0)
                {
                    for (int i = 0; i < Channels.Length; i++)
                    {
                        if (Channels[i].EndsWith("ai0"))
                        {
                            _physicalChannelLaser = Channels[i];
                            break;
                        }
                    }

                    for (int i = 0; i < Channels.Length; i++)
                    {
                        if (Channels[i].EndsWith("ai1"))
                        {
                            _physicalChannelTrigger = Channels[i];
                            break;
                        }
                    }

                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }

        private void CreateTask()
        {
            if (string.IsNullOrEmpty(_physicalChannelLaser) ||
                string.IsNullOrEmpty(_physicalChannelTrigger))
                throw new Exception("Physical channels are not set.");

            _usb6008Task = new Task();

            _usb6008Task.AIChannels.CreateVoltageChannel(_physicalChannelLaser,
                                                      "ai0",
                                                      AITerminalConfiguration.Rse,
                                                      0,
                                                      10,
                                                      AIVoltageUnits.Volts);

            _usb6008Task.AIChannels.CreateVoltageChannel(_physicalChannelTrigger,
                                              "ai1",
                                              AITerminalConfiguration.Rse,
                                              0,
                                              10,
                                              AIVoltageUnits.Volts);

            _usb6008Task.Control(TaskAction.Verify);

            _usb6008Task.Timing.ConfigureSampleClock(string.Empty,
                                                  _usb6008Task.Timing.SampleClockMaximumRate,
                                                  SampleClockActiveEdge.Rising,
                                                  SampleQuantityMode.ContinuousSamples);
        }

        private void StartTask()
        {
            _usb6008Task.Start();
        }

        private void CreateUSB6008Reader()
        {
            _usb6008Reader = new AnalogMultiChannelReader(_usb6008Task.Stream);
        }

        private void StartReadingUSB6008Data()
        {
            _usb6008Reader.BeginReadMultiSample((int)_usb6008Task.Timing.SampleClockMaximumRate,
                                               ReadCompleted,
                                               null);
        }

        private void ReadCompleted(IAsyncResult ar)
        {
            Console.WriteLine("Read Completed");
            double[,] data = _usb6008Reader.EndReadMultiSample(ar);

            if (_isManualStartStop)
            {
                if (_isManualScanStarted)
                {
                    if (!_readingSample)
                    {
                        BeginReading();
                        _readingSample = true;
                    }

                    for (int i = 0; i < data.GetLength(1); i++)
                    {
                        _laserReadings.Add(data[0, i]);
                    }
                }
                else
                {
                    if (_readingSample)
                    {
                        for (int i = 0; i < data.GetLength(1); i++)
                        {
                            _laserReadings.Add(data[0, i]);
                        }

                        _readingSample = false;
                        EndReading();
                    }
                }
            }
            else
            {
                if (!_readingSample)
                {
                    int startIndex;
                    bool readingStarted = CheckReadingSampleStarted(data, out startIndex);
                    if (readingStarted)
                    {
                        BeginReading();

                        for (int i = startIndex; i < data.GetLength(1); i++)
                        {
                            _laserReadings.Add(data[0, i]);
                        }

                        _readingSample = true;
                    }
                }
                else
                {
                    int stopIndex;
                    bool readingStopped = CheckReadingSampleStopped(data, out stopIndex);
                    if (readingStopped)
                    {
                        for (int i = 0; i < stopIndex; i++)
                        {
                            _laserReadings.Add(data[0, i]);
                        }

                        _readingSample = false;

                        EndReading();
                    }
                    else
                    {
                        for (int i = 0; i < data.GetLength(1); i++)
                        {
                            _laserReadings.Add(data[0, i]);
                        }
                    }
                }
            }

            if (_isLaserConnected && _readSamples)
            {
                _usb6008Reader.BeginReadMultiSample((int)_usb6008Task.Timing.SampleClockMaximumRate,
                                                   ReadCompleted,
                                                   null);
            }
        }

        private bool CheckReadingSampleStarted(double[,] data, out int startIndex)
        {
            bool aboveTriggerValueFound = false;

            startIndex = int.MinValue;
            for (int i = 0; i < data.GetLength(1); i++)
            {
                if (data[1, i] > START_VOLTAGE_TRIGGER)
                {
                    startIndex = i;
                    aboveTriggerValueFound = true;
                    break;
                }
            }

            double average = 0;

            if (aboveTriggerValueFound)
            {
                for (int i = startIndex; i < data.GetLength(1); i++)
                {
                    average += data[1, i];
                }

                average /= (data.GetLength(1) - startIndex);
            }

            if (average >= START_VOLTAGE_TRIGGER)
                return true;
            else
                return false;
        }

        private bool CheckReadingSampleStopped(double[,] data, out int stopIndex)
        {
            bool belowTriggerValueFound = false;

            stopIndex = int.MaxValue;
            for (int i = data.GetLength(1) - 1; i >= 0; i--)
            {
                if (data[1, i] < STOP_VOLTAGE_TRIGGER)
                {
                    stopIndex = i;
                    belowTriggerValueFound = true;
                    break;
                }
            }

            double average = 0;

            if (belowTriggerValueFound)
            {
                for (int i = 0; i <= stopIndex; i++)
                {
                    average += data[1, i];
                }

                average /= (stopIndex + 1);

                if (average <= STOP_VOLTAGE_TRIGGER)
                    return true;
                else
                    return false;
            }
            else
            {
                return false;
            }
        }

        private void BeginReading()
        {
            Console.WriteLine("Begin Reading Started");
            _laserReadings.Clear();

            if (ScanStarted != null)
            {
                ScanStarted();
            }
        }

        private void EndReading()
        {
            Console.WriteLine("Begin Reading Ended");

            int removedReadings;
            _laserReadings = FilterResults(_laserReadings, out removedReadings);

            if ((double)removedReadings / (double)_laserReadings.Count > 0.05)
            {
                //System.Windows.MessageBox.Show("Possible contamination detected.  Please make sure your optics are clean."); 
            }

            Console.WriteLine("Creating Scan");

            CTScan colorTrackScan = CreateScan(_laserReadings);

            Console.WriteLine("Scan Created");

            if (ScanCompleted != null)
            {
                Console.WriteLine("ScanCompleted != null");
                ScanCompleted(colorTrackScan);
            }            
        }

        private CTScan CreateScan(List<double> readings)
        {
            CTScan scan = new CTScan()
            {
                DateTime = DateTime.Now,
                Name = "Untitled",
                Attributes = new Dictionary<string, string>(),
                ScanResults = new Dictionary<string, CTScanResult>()
            };

            foreach (CTAttribute colorTrackAttribute in App.ColorTrackConfig.ColorTrackAttributes)
            {
                scan.Attributes.Add(colorTrackAttribute.Name, colorTrackAttribute.Value);
            }

            List<double> ctRawReadings = CalculateRawColorTrackReadings(readings);

            foreach (CTScale ctScale in App.ColorTrackConfig.CTScales)
            {
                List<double> ctScaledReadings = CalculateScaledReadings(ctRawReadings, ctScale);

                CTScanResult colorTrackScanResult = new CTScanResult();
                colorTrackScanResult.ScaleName = ctScale.Name;
                colorTrackScanResult.Average = Utils.CalculateAverage(ctScaledReadings);
                colorTrackScanResult.StandardDeviation = Utils.CalculateStandardDeviation(ctScaledReadings);
                colorTrackScanResult.Minimum = Utils.CalculateMinimum(ctScaledReadings);
                colorTrackScanResult.Maximum = Utils.CalculateMaximum(ctScaledReadings);
                colorTrackScanResult.HistogramBins = Utils.CalculateHistogramBins(ctScaledReadings);
                colorTrackScanResult.Mode = Utils.CalculateMode(colorTrackScanResult.HistogramBins);

                scan.ScanResults.Add(ctScale.Name, colorTrackScanResult);
            }

            return scan;
        }

	// HERE IS THE CODE THAT DOES THE SCALING OF THE RAW READING
        private List<double> CalculateRawColorTrackReadings(List<double> readings)
        {
            List<double> ctReadings = new List<double>();

            foreach (double reading in readings)
            {
                ctReadings.Add(reading * reading * 0.85);
            }

            return ctReadings;
        }

        private List<double> CalculateScaledReadings(List<double> ctRawReadings, CTScale ctScale)
        {
            ctScale.ScalePoints = ctScale.ScalePoints.OrderBy(x => x.InstrumentReading).ToList();

            List<double> ctScaledReadings = new List<double>();

            foreach(double ctRawReading in ctRawReadings)
            {
                ctScaledReadings.Add(ScaleReading(ctRawReading, ctScale));
            }

            return ctScaledReadings;
        }

        private double ScaleReading(double reading, CTScale ctScale)
        {
            if (ctScale.ScalePoints.Count == 1)
            {
                return ctScale.ScalePoints[0].ScaleReading;
            }

            // Add low point
            if (ctScale.ScalePoints[0].InstrumentReading > -10)
            {
                var sp = ctScale.ScalePoints;

                double ml = (sp[1].ScaleReading - sp[0].ScaleReading) /
                (sp[1].InstrumentReading - sp[0].InstrumentReading);

                double bl = sp[0].ScaleReading - ml * sp[0].InstrumentReading;

                double rl = ml * -10 + bl;

                ctScale.ScalePoints.Insert(0, new CTScalePoint()
                {
                    InstrumentReading = -10,
                    ScaleReading = rl
                });
            }

            // Add high point
            var highIndex = ctScale.ScalePoints.Count - 1;
            if (ctScale.ScalePoints[highIndex].InstrumentReading < 110)
            {
                var sp = ctScale.ScalePoints;

                double mh = (sp[highIndex].ScaleReading - sp[highIndex - 1].ScaleReading) /
                (sp[highIndex].InstrumentReading - sp[highIndex - 1].InstrumentReading);

                double bh = sp[highIndex - 1].ScaleReading - mh * sp[highIndex - 1].InstrumentReading;

                double rh = mh * 110 + bh;

                ctScale.ScalePoints.Add(new CTScalePoint()
                {
                    InstrumentReading = 110,
                    ScaleReading = rh
                });
            }

            var scalePoints = ctScale.ScalePoints;

            // Find correct endpoints
            int lowEndpointIndex = 0;
            bool found = false;
            for (int i = scalePoints.Count - 1; i >= 0; i--)
            {
                if (reading > scalePoints[i].InstrumentReading)
                {
                    lowEndpointIndex = i;
                    found = true;
                    break;
                }
            }

            if (found == false)
            {
                throw new InvalidOperationException("Scale out of range");
            }

            if (lowEndpointIndex == scalePoints.Count - 1)
            {
                throw new InvalidOperationException("Scale out of range");
            }

            double m = (scalePoints[lowEndpointIndex + 1].ScaleReading - scalePoints[lowEndpointIndex].ScaleReading) /
                (scalePoints[lowEndpointIndex + 1].InstrumentReading - scalePoints[lowEndpointIndex].InstrumentReading);

            double b = scalePoints[lowEndpointIndex].ScaleReading - m * scalePoints[lowEndpointIndex].InstrumentReading;

            double scaledReading = m * reading + b;

            return scaledReading;

            /*double scaledReading;

            scaledReading = (colorTrackScale.DesiredDarkReading - colorTrackScale.DesiredLightReading) /
                            (colorTrackScale.ActualDarkReading - colorTrackScale.ActualLightReading) *
                            (reading - colorTrackScale.ActualLightReading) +
                            colorTrackScale.DesiredLightReading;

            return scaledReading;*/
        }

        private static List<double> FilterResults(List<double> readings, out int removedReadings)
        {
            List<double> filteredReadings = new List<double>();

            removedReadings = 0;

            foreach (double reading in readings)
            {
                if (reading > VOLTAGE_READING_LOWER_BOUND)
                {
                    filteredReadings.Add(reading);
                }
                else
                {
                    removedReadings++;
                }
            }

            return filteredReadings;
        }

        #endregion
    }
}