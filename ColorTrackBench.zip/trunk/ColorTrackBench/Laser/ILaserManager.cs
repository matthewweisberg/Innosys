﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ColorTrackBench.Common;

namespace ColorTrackBench.Laser
{
    public interface ILaserManager
    {
        event Action LaserConnected;
        event Action LaserDisconnected;

        event Action ScanStarted;
        event Action<CTScan> ScanCompleted;

        void Stop();

        void SetManualStartStop(bool manualStartStop);

        void StartManualScan();

        void StopManualScan();
    }
}
