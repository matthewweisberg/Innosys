﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ColorTrackBench.Common;
using InnosysLaserInterface;
using System.Threading;
using System.Runtime.InteropServices;
using System.ComponentModel;

namespace ColorTrackBench.Laser
{
    public class InnosysLaserManager : ILaserManager
    {
        #region Members

        private LaserAgent _laserAgent;
        private bool _pollingEnabled;
        private bool _readingStarted;

        #endregion
        
        #region ILaserManager Members

        public event Action LaserConnected;

        public event Action LaserDisconnected;

        public event Action ScanStarted;

        public event Action<CTScan> ScanCompleted;

        public void Stop()
        {
            _pollingEnabled = false;
        }

        public void SetManualStartStop(bool manualStartStop)
        {
            throw new NotImplementedException();
        }

        public void StartManualScan()
        {
            throw new NotImplementedException();
        }

        public void StopManualScan()
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Constructor

        public InnosysLaserManager()
        {
            _pollingEnabled = true;

            bool isWow64 = NativeMethods.Is64Bit();
            _laserAgent = new LaserAgent(isWow64);

            PollPowerPin();
        }

        #endregion

        #region Functions

        private void StartLaserConnectedDetection()
        {
            Thread thread = new Thread(new ThreadStart(() =>
                {
                    var result = _laserAgent.LmEnableDevice();

                    while (result != LmResult.LM_SUCCESS)
                    {
                        Thread.Sleep(1000);
                        result = _laserAgent.LmEnableDevice();
                    }

                    var laserConnected = LaserConnected;
                    if (laserConnected != null)
                        laserConnected();
                }));
        }

        private void PollPowerPin()
        {
            while (_pollingEnabled)
            {
                bool powerOn;
                var result = _laserAgent.LmGetPowerPin(out powerOn);
                Console.WriteLine("PollPowerPin: Result - {0}, ReadingStarted - {1}", result, powerOn);

                if (result == LmResult.LM_SUCCESS && powerOn && !_readingStarted)
                {
                    var scanStarted = ScanStarted;
                    if (scanStarted != null)
                        scanStarted();

                    PerformScan();
                }

                Thread.Sleep(1000);
            }
        }

        private void PerformScan()
        {
            _laserAgent.LmStartLightAdcAutoRead(LmReadRate.LM_READ_RATE_15);

            bool read;
            LmResult result;

            var readings = new List<int>();

            do
            {
                int lightReading;
                result = _laserAgent.LmGetLightData(out lightReading);

                if (result == LmResult.LM_SUCCESS)
                    readings.Add(lightReading);

                Thread.Sleep(TimeSpan.FromTicks(500));

                result = _laserAgent.LmGetPowerPin(out read);
            } while (result == LmResult.LM_SUCCESS && read == true);

            _laserAgent.LmStopLightAdcAutoRead();

            var scanCompleted = ScanCompleted;
            if (scanCompleted != null)
            {
                var ctScan = new CTScan();
                scanCompleted(ctScan);
            }

            PollPowerPin();
        }

        #endregion
    }
}
