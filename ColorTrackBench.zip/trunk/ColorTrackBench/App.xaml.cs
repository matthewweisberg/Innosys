﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;
using System.IO;
using System.Xml;
using System.Runtime.Serialization;
using ColorTrackBench.Common;
using ColorTrackBench.Builders;
using ColorTrackBench.Laser;

namespace ColorTrackBench
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public const string COLORTRACK_DIRECTORY = @"C:\Fresh Roast Systems\ColorTrack - Laser Color Analyzer\";
        public const string CONFIG_DIRECTORY = @"C:\Fresh Roast Systems\ColorTrack - Laser Color Analyzer\Config\";
        
        public const string CONFIG_FILENAME = "ColorTrackBenchConfig.xml";
        
        public static ILaserManager ILaserManager { get; set; }
        public static ColorTrackManager ColorTrackManager { get; set; }
        public static CTConfig ColorTrackConfig { get; set; }

        private void Application_Startup(object sender, StartupEventArgs e)
        {
            ColorTrackManager = new ColorTrackBench.ColorTrackManager();

            checkCreateDefaultDirectory();
            LoadColorTrackConfig();

            if (ColorTrackConfig.LaserType == LaserType.Innosys)
                ILaserManager = new InnosysLaserManager();
            else
                ILaserManager = new FRSLaserManager();
            
            MainWindow = new MainWindow();
            MainWindow.Show();
        }

        private void checkCreateDefaultDirectory()
        {
            if (!Directory.Exists(COLORTRACK_DIRECTORY))
            {
                DirectoryInfo di = Directory.CreateDirectory(COLORTRACK_DIRECTORY);
            }

            if (!Directory.Exists(CONFIG_DIRECTORY))
            {
                DirectoryInfo di = Directory.CreateDirectory(CONFIG_DIRECTORY);
            }
        }

        public static void LoadColorTrackConfig()
        {
            if (File.Exists(CONFIG_DIRECTORY + CONFIG_FILENAME))
            {
                FileStream fs = new FileStream(CONFIG_DIRECTORY + CONFIG_FILENAME, FileMode.OpenOrCreate);
                XmlDictionaryReader reader = XmlDictionaryReader.CreateTextReader(fs, new XmlDictionaryReaderQuotas());
                DataContractSerializer ser = new DataContractSerializer(typeof(CTConfig));
                ColorTrackConfig = (CTConfig)ser.ReadObject(reader);
                reader.Close();
                fs.Close();
            }
            else
            {
                ColorTrackConfig = new CTConfigBuilder().Build();
                SaveColorTrackConfig();
            }
        }

        public static void SaveColorTrackConfig()
        {
            FileStream fs = new FileStream(CONFIG_DIRECTORY + CONFIG_FILENAME, FileMode.Create);
            XmlDictionaryWriter writer = XmlDictionaryWriter.CreateTextWriter(fs);
            DataContractSerializer ser = new DataContractSerializer(typeof(CTConfig));
            ser.WriteObject(writer, ColorTrackConfig);
            writer.Close();
            fs.Close();
        }
    }
}
