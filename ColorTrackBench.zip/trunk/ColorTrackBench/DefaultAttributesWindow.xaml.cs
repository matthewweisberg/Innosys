﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Interop;
using System.Collections.ObjectModel;
using System.Runtime.InteropServices;
using ColorTrackBench.Common;

namespace ColorTrackBench
{
    /// <summary>
    /// Interaction logic for DefaultAttributesWindow.xaml
    /// </summary>
    public partial class DefaultAttributesWindow : Window
    {
        #region Remove Close Button

        private const int GWL_STYLE = -16;
        private const int WS_SYSMENU = 0x80000;
        
        [DllImport("user32.dll", SetLastError = true)]
        private static extern int GetWindowLong(IntPtr hWnd, int nIndex);
        
        [DllImport("user32.dll")]
        private static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

        private void defaultAttributesWindow_Loaded(object sender, RoutedEventArgs e)
        {
            var hwnd = new WindowInteropHelper(this).Handle;
            SetWindowLong(hwnd, GWL_STYLE, GetWindowLong(hwnd, GWL_STYLE) & ~WS_SYSMENU);
        }

        #endregion Remove Close Button

        public ObservableCollection<CTAttribute> colorTrackAttributes { get; set; }

        public DefaultAttributesWindow()
        {
            InitializeComponent();

            colorTrackAttributes = new ObservableCollection<CTAttribute>();

            foreach (CTAttribute colorTrackAttribute in App.ColorTrackConfig.ColorTrackAttributes)
            {
                colorTrackAttributes.Add(colorTrackAttribute);
            }

            dgAttributes.ItemsSource = colorTrackAttributes;
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            App.ColorTrackConfig.ColorTrackAttributes = colorTrackAttributes.ToList<CTAttribute>();

            App.SaveColorTrackConfig();

            this.Close();
        }        
    }
}