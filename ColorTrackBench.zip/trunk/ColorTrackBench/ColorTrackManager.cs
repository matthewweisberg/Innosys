﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml;
using System.Runtime.Serialization;
using ColorTrackBench.Common;

namespace ColorTrackBench
{
    public class ColorTrackManager
    {
        #region Load/Save ColorTrack Scans

        public bool LoadColorTrackScan(string filename, out CTScan colorTrackScan)
        {
            if (File.Exists(filename))
            {
                try
                {
                    FileStream fs = new FileStream(filename, FileMode.OpenOrCreate);
                    XmlDictionaryReader reader = XmlDictionaryReader.CreateTextReader(fs, new XmlDictionaryReaderQuotas());
                    DataContractSerializer ser = new DataContractSerializer(typeof(CTScan));
                    colorTrackScan = (CTScan)ser.ReadObject(reader);
                    reader.Close();
                    fs.Close();
                }
                catch
                {
                    colorTrackScan = null;

                    return false;
                }

                return true;
            }
            else
            {
                colorTrackScan = null;

                return false;
            }
        }

        public bool SaveColorTrackScan(string filename, CTScan colorTrackScan)
        {
            try
            {
                FileStream fs = new FileStream(filename, FileMode.Create);
                XmlDictionaryWriter writer = XmlDictionaryWriter.CreateTextWriter(fs);
                DataContractSerializer ser = new DataContractSerializer(typeof(CTScan));
                ser.WriteObject(writer, colorTrackScan);
                writer.Close();
                fs.Close();

                return true;
            }
            catch
            {
                return false;
            }

        }

        #endregion Load/Save ColorTrack Scans
    }
}
