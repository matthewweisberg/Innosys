﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Runtime.InteropServices;
using System.Windows.Interop;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.ComponentModel;
using ColorTrackBench.Common;

namespace ColorTrackBench
{
    /// <summary>
    /// Interaction logic for ScaleWindow.xaml
    /// </summary>
    public partial class ScaleWindow : Window
    {
        #region Remove Close Button

        private const int GWL_STYLE = -16;
        private const int WS_SYSMENU = 0x80000;

        [DllImport("user32.dll", SetLastError = true)]
        private static extern int GetWindowLong(IntPtr hWnd, int nIndex);

        [DllImport("user32.dll")]
        private static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var hwnd = new WindowInteropHelper(this).Handle;
            SetWindowLong(hwnd, GWL_STYLE, GetWindowLong(hwnd, GWL_STYLE) & ~WS_SYSMENU);
        }

        #endregion Remove Close Button

        public bool CancelClicked { get; set; }
        public ObservableCollection<CTScalePoint> ScalePoints { get; set; }
        public string ScaleTitle { get; set; }
        
        public ScaleWindow()
        {
            InitializeComponent();

            ScalePoints = new ObservableCollection<CTScalePoint>();
            dgScalePoints.ItemsSource = ScalePoints;

            CancelClicked = true;
        }

        public ScaleWindow(List<CTScalePoint> scalePoints)
        {
            InitializeComponent();

            ScalePoints = new ObservableCollection<CTScalePoint>(scalePoints);
            dgScalePoints.ItemsSource = ScalePoints;

            CancelClicked = true;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            CancelClicked = false;
            ScaleTitle = txtScaleName.Text;

            if (verifyPoints())
            {
                this.Close();
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            CancelClicked = true;
            ScaleTitle = txtScaleName.Text;

            this.Close();
        }

        private bool verifyPoints()
        {
            if (txtScaleName.Text.Trim() == "")
            {
                MessageBox.Show("Please enter a Scale Name", "Scale Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (ScalePoints.Count < 2)
            {
                MessageBox.Show("Please enter at least 2 points", "Scale Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            List<double> instrumentReadings = new List<double>();

            for (int i = 0; i < ScalePoints.Count; i++)
            {
                for (int j = 0; j < instrumentReadings.Count; j++)
                {
                    if (ScalePoints[i].InstrumentReading == instrumentReadings[j])
                    {
                        MessageBox.Show("Duplicate values for Instrument Readings are not allowed", "Scale Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        return false;
                    }
                }
                instrumentReadings.Add(ScalePoints[i].InstrumentReading);
            }

            return true;
        }
    }
}
