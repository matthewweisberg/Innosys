﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Interop;
using System.Runtime.InteropServices;
using System.Collections.ObjectModel;
using ColorTrackBench.Common;

namespace ColorTrackBench
{
    /// <summary>
    /// Interaction logic for ScalesWindow.xaml
    /// </summary>
    public partial class ScalesWindow : Window
    {
        #region Remove Close Button

        private const int GWL_STYLE = -16;
        private const int WS_SYSMENU = 0x80000;

        [DllImport("user32.dll", SetLastError = true)]
        private static extern int GetWindowLong(IntPtr hWnd, int nIndex);

        [DllImport("user32.dll")]
        private static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var hwnd = new WindowInteropHelper(this).Handle;
            SetWindowLong(hwnd, GWL_STYLE, GetWindowLong(hwnd, GWL_STYLE) & ~WS_SYSMENU);
        }

        #endregion Remove Close Button

        public ObservableCollection<CTScale> CTScales;

        public ScalesWindow()
        {
            InitializeComponent();

            CTScales = new ObservableCollection<CTScale>(App.ColorTrackConfig.CTScales);
            lbxScales.ItemsSource = CTScales;


        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            ScaleWindow scaleWindow = new ScaleWindow();
            scaleWindow.ShowDialog();

            if (scaleWindow.CancelClicked == false)
            {
                App.ColorTrackConfig.CTScales.Add(new CTScale()
                {
                    Name = scaleWindow.ScaleTitle,
                    ScalePoints = scaleWindow.ScalePoints.ToList()
                });

                App.SaveColorTrackConfig();

                CTScales = new ObservableCollection<CTScale>(App.ColorTrackConfig.CTScales);
                lbxScales.ItemsSource = CTScales;
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            App.ColorTrackConfig.DeleteCTScale(((CTScale)lbxScales.SelectedValue).Name);
            App.SaveColorTrackConfig();

            CTScales = new ObservableCollection<CTScale>(App.ColorTrackConfig.CTScales);
            lbxScales.ItemsSource = CTScales;
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            CTScale selectedScale = (CTScale)lbxScales.SelectedValue;
            string originalName = selectedScale.Name;

            ScaleWindow scaleWindow = new ScaleWindow(selectedScale.ScalePoints);
            scaleWindow.ScaleTitle = selectedScale.Name;
            scaleWindow.txtScaleName.Text = selectedScale.Name;

            scaleWindow.ShowDialog();

            if (scaleWindow.CancelClicked == false)
            {
                App.ColorTrackConfig.ChangeCTScale(originalName, new CTScale()
                {
                    Name = scaleWindow.ScaleTitle,
                    ScalePoints = scaleWindow.ScalePoints.ToList()
                });

                App.SaveColorTrackConfig();

                CTScales = new ObservableCollection<CTScale>(App.ColorTrackConfig.CTScales);
                lbxScales.ItemsSource = CTScales;
            }
        }

        private void lbxScales_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lbxScales.SelectedIndex >= 0)
            {
                btnEdit.IsEnabled = true;
                btnDelete.IsEnabled = true;
            }
            else
            {
                btnEdit.IsEnabled = false;
                btnDelete.IsEnabled = false;
            }
        }
    }
}
