﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace ColorTrackBench.Common
{
    [DataContract]
    public class CTScan
    {
        [DataMember]
        public string Name { get; set; }

        [DataMember]
        public DateTime DateTime { get; set; }

        [DataMember]
        public Dictionary<string, string> Attributes { get; set; }

        [DataMember]
        public Dictionary<string, CTScanResult> ScanResults { get; set; }

        [DataMember]
        public string Comments { get; set; }
    }
}
