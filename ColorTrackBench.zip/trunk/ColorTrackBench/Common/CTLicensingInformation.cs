﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace ColorTrackBench.Common
{
    [DataContract]
    public class CTLicensingInformation
    {
        [DataMember]
        public string Name { get; set; }

        [DataMember]
        public string Company { get; set; }

        [DataMember]
        public string LicenseKey { get; set; }
    }
}
