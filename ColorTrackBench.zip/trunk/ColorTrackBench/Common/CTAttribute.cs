﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.ComponentModel;

namespace ColorTrackBench.Common
{
    [DataContract]
    public class CTAttribute : INotifyPropertyChanged
    {
        private string ctaname;
        private string ctavalue;

        [DataMember]
        public string Name
        {
            get { return ctaname; }
            set
            {
                if (ctaname != value)
                {
                    ctaname = value;
                    NotifyPropertyChanged("Name");
                }
            }
        }

        [DataMember]
        public string Value
        {
            get { return ctavalue; }
            set
            {
                if (ctavalue != value)
                {
                    ctavalue = value;
                    NotifyPropertyChanged("Value");
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs((propertyName)));
            }
        }
    }
}
