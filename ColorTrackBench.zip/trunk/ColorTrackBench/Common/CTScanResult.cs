﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace ColorTrackBench.Common
{
    [DataContract]
    public class CTScanResult
    {
        [DataMember]
        public string ScaleName { get; set; }

        [DataMember]
        public double Average { get; set; }

        [DataMember]
        public double StandardDeviation { get; set; }

        [DataMember]
        public double Minimum { get; set; }

        [DataMember]
        public double Maximum { get; set; }

        [DataMember]
        public double Mode { get; set; }

        [DataMember]
        public Dictionary<int, int> HistogramBins { get; set; }
    }
}
