﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace ColorTrackBench.Common
{
    [DataContract]
    public class CTConfig
    {
        [DataMember]
        public LaserType LaserType { get; set; }

        [DataMember]
        public string Scale { get; set; }

        [DataMember]
        public int NumberOfDecimalsAverage { get; set; }

        [DataMember]
        public int NumberOfDecimalsStandardDeviation { get; set; }

        [DataMember]
        public CTLicensingInformation ColorTrackLicensingInformation { get; set; }

        [DataMember]
        public List<CTAttribute> ColorTrackAttributes { get; set; }

        [DataMember]
        public List<CTScale> CTScales { get; set; }

        public CTScale GetCTScaleByName(string name)
        {
            foreach (CTScale ctScale in CTScales)
            {
                if (ctScale.Name == name)
                {
                    return ctScale;
                }
            }

            throw new KeyNotFoundException("ColorTrack Scale Not Found");
        }

        public void DeleteCTScale(string name)
        {
            CTScale scaleRemove = null;

            foreach (CTScale ctScale in CTScales)
            {
                if (ctScale.Name == name)
                {
                    scaleRemove = ctScale;
                    break;
                }
            }

            if (scaleRemove == null)
            {
                throw new KeyNotFoundException("ColorTrack Scale Not Found");
            }
            else
            {
                CTScales.Remove(scaleRemove);
            }
        }

        public void ChangeCTScale(string originalName, CTScale scale)
        {
            int foundIndex = -1;

            for (int i = 0; i < CTScales.Count; i++)
            {
                if (CTScales[i].Name == originalName)
                {
                    foundIndex = i;
                    break;
                }
            }

            if (foundIndex == -1)
            {
                throw new KeyNotFoundException("ColorTrack Scale Not Found");
            }
            else
            {
                CTScales[foundIndex] = scale;
            }

        }

        public void AddCTScale(CTScale scale)
        {
            foreach (CTScale ctScale in CTScales)
            {
                if (ctScale.Name == scale.Name)
                {
                    throw new ArgumentException("ColorTrack Scale Name Already Exists");
                }
            }

            CTScales.Add(scale);
        }
    }
}
