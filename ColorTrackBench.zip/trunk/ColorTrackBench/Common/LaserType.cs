﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace ColorTrackBench.Common
{
    [DataContract]
    public enum LaserType
    {
        [EnumMember]
        FRS,

        [EnumMember]
        Innosys
    }
}
