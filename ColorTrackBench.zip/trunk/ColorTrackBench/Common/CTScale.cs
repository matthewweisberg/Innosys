﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace ColorTrackBench.Common
{
    [DataContract]
    public class CTScale
    {
        [DataMember]
        public string Name { get; set; }

        [DataMember]
        public List<CTScalePoint> ScalePoints { get; set; }
    }
}
