﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace ColorTrackBench.Common
{
    [DataContract]
    public class CTScalePoint
    {
        [DataMember]
        public double InstrumentReading { get; set; }

        [DataMember]
        public double ScaleReading { get; set; }
    }
}
