﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ColorTrackBench.Common;

namespace ColorTrackBench.Builders
{
    public class CTConfigBuilder
    {
        public LaserType LaserType { get; set; }
        public string Scale { get; set; }
        public CTLicensingInformation ColorTrackLicensingInformation { get; set; }
        public int NumberOfDecimalsAverage { get; set; }
        public int NumberOfDecimalsStandardDeviation { get; set; }
        public List<CTAttribute> ColorTrackAttributes { get; set; }
        public List<CTScale> CTScales { get; set; }

        public CTConfigBuilder()
        {
            LaserType = LaserType.FRS;
            Scale = "ColorTrack";
            NumberOfDecimalsAverage = 2;
            NumberOfDecimalsStandardDeviation = 4;

            ColorTrackLicensingInformation = new CTLicensingInformation()
            {
                Company = "Fresh Roast Systems",
                Name = "Fresh Roast Systems",
                LicenseKey = "3957-4782-548483-4959"
            };

            ColorTrackAttributes = new List<CTAttribute>();

            ColorTrackAttributes.Add(new CTAttribute()
            {
                Name = "Roast Name",
                Value = ""
            });

            ColorTrackAttributes.Add(new CTAttribute()
            {
                Name = "Tester",
                Value = ""
            });

            CTScales = new List<CTScale>();

            var ctScale = new CTScale()
            {
                Name = "ColorTrack",
                ScalePoints = new List<CTScalePoint>()
            };

            ctScale.ScalePoints.Add(new CTScalePoint()
            {
                InstrumentReading = 0,
                ScaleReading = 0
            });

            ctScale.ScalePoints.Add(new CTScalePoint()
            {
                InstrumentReading = 100,
                ScaleReading = 100
            });

            CTScales.Add(ctScale);

            var agtronScale = new CTScale()
            {
                Name = "Agtron",
                ScalePoints = new List<CTScalePoint>()
            };

            agtronScale.ScalePoints.Add(new CTScalePoint()
            {
                InstrumentReading = 0,
                ScaleReading = 91.1
            });

            agtronScale.ScalePoints.Add(new CTScalePoint()
            {
                InstrumentReading = 100,
                ScaleReading = 11.3
            });

            CTScales.Add(agtronScale);

            var nativeScale = new CTScale()
            {
                Name = "Native",
                ScalePoints = new List<CTScalePoint>()
            };

            nativeScale.ScalePoints.Add(new CTScalePoint()
            {
                InstrumentReading = 0,
                ScaleReading = 0
            });

            nativeScale.ScalePoints.Add(new CTScalePoint()
            {
                InstrumentReading = 100,
                ScaleReading = 100
            });

            CTScales.Add(nativeScale);
        }

        public CTConfig Build()
        {
            return new CTConfig()
            {
                LaserType = LaserType,
                Scale = Scale,
                NumberOfDecimalsAverage = NumberOfDecimalsAverage,
                NumberOfDecimalsStandardDeviation = NumberOfDecimalsStandardDeviation,
                ColorTrackLicensingInformation = ColorTrackLicensingInformation,
                ColorTrackAttributes = ColorTrackAttributes,
                CTScales = CTScales
            };
        }
    }
}
