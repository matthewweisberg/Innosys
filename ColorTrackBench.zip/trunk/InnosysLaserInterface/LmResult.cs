﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InnosysLaserInterface
{
    public enum LmResult
    {
        LM_SUCCESS = 0,
        LM_ERR_DATA_TOO_LARGE = -1,
        LM_ERR_TABLE_NOT_DEFINED = -2,
        LM_ERR_INVALID_TABLE_ID = -3,
        LM_ERR_NO_TABLES_DEFINED = -4,
        LM_ERR_BAD_PARAMETER = -5,
        LM_ERR_DRIVER_LOAD_FAILED = -6,
        LM_ERR_THREAD_CREATION_FAILED = -7,
        LM_ERR_DEVICE_WRITE_FAILED = -8,
        LM_ERR_DEVICE_READ_TIMEOUT = -9,
        LM_ERR_INVALID_RESPONSE = -10,
        LM_ERR_UNSPECIFIED = -11,
        LM_ERR_TABLE_BAD_CHECKSUM = -12,
        LM_ERR_DEVICE_READ_FAILED = -13,
        LM_ERR_DEVICE_IOCTL_CALL = -14,
        LM_ERR_DEVICE_READ_ZERO_LENGTH_DATA = -15,
        LM_ERR_DEVICE_RESPONSE_UNEXPECTED = -16,
        LM_ERR_DEVICE_NOT_ACTIVATED = -17,
        LM_ERR_DEVICE_ALREADY_ACTIVATED = -18,
        LM_ERR_DEVICE_BUSY = -19,
        LM_ERR_DIAG_PIPE_READ_ERROR = -20,
        LM_AUTO_READ_MODE_NO_DATA = -21
    }
}
