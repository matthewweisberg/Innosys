﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InnosysLaserInterface
{
    public class LaserAgent
    {
        private bool _use64BitVersion;

        public LaserAgent(bool use64BitVersion)
        {
            _use64BitVersion = use64BitVersion;
        }

        /// <summary>
        /// Returns the device's Product ID.
        /// </summary>
        /// <param name="productID">Device Product ID is a 4 character hexadecimal string.</param>
        /// <returns>LM_SUCCESS or error code</returns>
        public LmResult LmGetProductID(out string productID)
        {
            int pProductID;
            var result = _use64BitVersion ? LmUserDllx64Interface.LmGetProductID(out pProductID) : LmUserDllx86Interface.LmGetProductID(out pProductID);

            if (result == LmResult.LM_SUCCESS)
                productID = string.Format("{0:X4}", pProductID);
            else
                productID = string.Empty;

            return result;
        }

        /// <summary>
        /// Returns the maximum calibration table size allowed (in bytes).
        /// </summary>
        /// <returns>The maximum calibration table size allowed.</returns>
        public int LmGetMaxTableSize()
        {
            return _use64BitVersion ? LmUserDllx64Interface.LmGetMaxTableSize() : LmUserDllx86Interface.LmGetMaxTableSize();
        }

        public LmResult LmEnableDevice()
        {
            return _use64BitVersion ? LmUserDllx64Interface.LmEnableDevice() : LmUserDllx86Interface.LmEnableDevice();
        }

        public LmResult LmDisableDevice()
        {
            return _use64BitVersion ? LmUserDllx64Interface.LmDisableDevice() : LmUserDllx86Interface.LmDisableDevice();
        }

        public LmResult LmResetDevice()
        {
            return _use64BitVersion ? LmUserDllx64Interface.LmResetDevice() : LmUserDllx86Interface.LmResetDevice();
        }

        public LmResult LmStartLightAdcAutoRead(LmReadRate rate)
        {
            return _use64BitVersion ? LmUserDllx64Interface.LmStartLightAdcAutoRead(rate) : LmUserDllx86Interface.LmStartLightAdcAutoRead(rate);
        }

        public LmResult LmStopLightAdcAutoRead()
        {
            return _use64BitVersion ? LmUserDllx64Interface.LmStopLightAdcAutoRead() : LmUserDllx86Interface.LmStopLightAdcAutoRead();
        }

        public LmResult LmGetLightData(out int lightReading)
        {
            return _use64BitVersion ? LmUserDllx64Interface.LmGetLightData(out lightReading) : LmUserDllx86Interface.LmGetLightData(out lightReading);
        }

        public LmResult LmGetTemperatureData(out int temperatureReading)
        {
            return _use64BitVersion ? LmUserDllx64Interface.LmGetTemperatureData(out temperatureReading) : LmUserDllx86Interface.LmGetTemperatureData(out temperatureReading);
        }

        public LmResult LmGetPowerPin(out bool powerOn)
        {
            return _use64BitVersion ? LmUserDllx64Interface.LmGetPowerPin(out powerOn) : LmUserDllx86Interface.LmGetPowerPin(out powerOn);
        }

        public LmResult LmSelectCalibrationTable(LmCalibrationTableSelectionId tableID)
        {
            return _use64BitVersion ? LmUserDllx64Interface.LmSelectCalibrationTable(tableID) : LmUserDllx86Interface.LmSelectCalibrationTable(tableID);
        }

        public LmResult LmQueryCalibrationTableSelection(out LmCalibrationTableSelectionId TableID)
        {
            return _use64BitVersion ? LmUserDllx64Interface.LmQueryCalibrationTableSelection(out TableID) : LmUserDllx86Interface.LmQueryCalibrationTableSelection(out TableID);
        }
    }
}
