﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace InnosysLaserInterface
{
    static class LmUserDllx86Interface
    {
        [DllImport("LmUserDllx86.dll")]
        public static extern LmResult LmGetProductID(out int pProductID);

        [DllImport("LmUserDllx86.dll")]
        public static extern int LmGetMaxTableSize();

        [DllImport("LmUserDllx86.dll")]
        public static extern LmResult LmEnableDevice();

        [DllImport("LmUserDllx86.dll")]
        public static extern LmResult LmDisableDevice();

        [DllImport("LmUserDllx86.dll")]
        public static extern LmResult LmResetDevice();

        [DllImport("LmUserDllx86.dll")]
        public static extern LmResult LmStartLightAdcAutoRead(LmReadRate rate);

        [DllImport("LmUserDllx86.dll")]
        public static extern LmResult LmStopLightAdcAutoRead();

        [DllImport("LmUserDllx86.dll")]
        public static extern LmResult LmGetLightData(out int lightReading);

        [DllImport("LmUserDllx86.dll")]
        public static extern LmResult LmGetTemperatureData(out int temperatureReading);

        [DllImport("LmUserDllx86.dll")]
        public static extern LmResult LmGetPowerPin(out bool powerOn);

        [DllImport("LmUserDllx86.dll")]
        public static extern LmResult LmSelectCalibrationTable(LmCalibrationTableSelectionId tableID);

        [DllImport("LmUserDllx86.dll")]
        public static extern LmResult LmQueryCalibrationTableSelection(out LmCalibrationTableSelectionId TableID);
    }
}
