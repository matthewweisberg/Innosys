﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InnosysLaserInterface
{
    public enum LmReadRate
    {
        LM_READ_RATE_375 = 0,       // 3.75 hz	(266.67 ms)
        LM_READ_RATE_75 = 2,        // 7.5 hz	(133.33 ms)
        LM_READ_RATE_15 = 3         // 15 hz	( 66.67 ms)
    }
}
