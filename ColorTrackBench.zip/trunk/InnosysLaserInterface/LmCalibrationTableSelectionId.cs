﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InnosysLaserInterface
{
    public enum LmCalibrationTableSelectionId
    {
        LM_TABLE_NOT_SET = 0xff,
        LM_FACTORY_TABLE = 1,
        LM_USER_TABLE = 2
    }
}
